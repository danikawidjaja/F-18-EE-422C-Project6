in order to avoid redundancy, please manually copy tests from assignment6 directory to here.
